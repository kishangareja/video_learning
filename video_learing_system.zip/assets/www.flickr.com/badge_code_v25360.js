var b_txt = '';

// Write a warning for the developer
b_txt+= '<!-- DEVELOPER WARNING: The Flickr badge code is likely to be deprecated, and we recommend changing to a new method to embed photo as soon as possible.  See https://www.flickr.com/api for information on how to access Flickr data. Thanks. -->';

// write the badge
	
	
		 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image1"><a href="../www.flickr.com/photos/chapter3/3221707896/index.html"><img src="https://live.staticflickr.com/3311/3221707896_54893861e8_s.jpg" alt="A photo on Flickr" title="2005 August - NYC views" height="75" width="75"></a></div>';

	
		 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image2"><a href="../www.flickr.com/photos/chapter3/3221704130/index.html"><img src="https://live.staticflickr.com/3387/3221704130_31953201cd_s.jpg" alt="A photo on Flickr" title="2005 August - NYC views" height="75" width="75"></a></div>';

	
		 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image3"><a href="../www.flickr.com/photos/chapter3/3221702350/index.html"><img src="https://live.staticflickr.com/3362/3221702350_b9f44ffba2_s.jpg" alt="A photo on Flickr" title="2005 August - NYC views" height="75" width="75"></a></div>';

	
		 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image4"><a href="../www.flickr.com/photos/chapter3/3221701778/index.html"><img src="https://live.staticflickr.com/3305/3221701778_aa494eb761_s.jpg" alt="A photo on Flickr" title="2005 August - NYC views" height="75" width="75"></a></div>';

	
		 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image5"><a href="../www.flickr.com/photos/chapter3/3221701148/index.html"><img src="https://live.staticflickr.com/3317/3221701148_d700e1582e_s.jpg" alt="A photo on Flickr" title="2005 August - NYC views" height="75" width="75"></a></div>';

	
		 	 		
	b_txt+= '<div class="flickr_badge_image" id="flickr_badge_image6"><a href="../www.flickr.com/photos/chapter3/3221699962/index.html"><img src="https://live.staticflickr.com/3418/3221699962_e619a5f7f6_s.jpg" alt="A photo on Flickr" title="2005 August - NYC views" height="75" width="75"></a></div>';


b_txt += '<span style="position:absolute;left:-999em;top:-999em;visibility:hidden" class="flickr_badge_beacon"><img src="https://geo.yahoo.com/p?s=792600102&t=6b27042da0a41909c841a545b461926d&r=http%3A%2F%2Fuacademy.html.themeforest.createit.pl%2Findex.html&fl_ev=0&lang=en&intl=in" width="0" height="0" alt="" /></span>';

document.write(b_txt);