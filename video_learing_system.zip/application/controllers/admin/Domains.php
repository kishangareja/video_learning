<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Domains extends CI_Controller {

	function __construct() {

		parent::__construct();
		$this->load->model(array('domain_model'));
		$this->gdb->checkAdminLogin();

	}

	public function index() {
		$data['domain_data'] = $this->domain_model->getDomain();
		$data['view'] = 'admin/domains/view';
		$data['page_title'] = 'Domain List';
		$this->load->view('admin/admin_master', $data);
	}

	public function add($id = 0) {
		$id = $id + 0;
		$data['page_title'] = 'Add Domain';
		$data['view'] = 'admin/domains/add';
		$action = 'Add';
		if ($id) {
			$this->data['page_title'] = 'Edit Domain';
			$action = 'Edit';
		}

		if ($id) {
			$data['domain_data'] = $this->domain_model->getDomainById($id);
		}

		$this->form_validation->set_error_delimiters('<div id="alrt" class="alert alert-danger" style="padding:5px;margin-top:5px;">', '</div>');
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('domain_date', 'Date', 'required');
		$this->form_validation->set_rules('duration', 'Duration', 'required');
		$this->form_validation->set_rules('start_time', 'Start Time', 'required');
		$this->form_validation->set_rules('end_time', 'End Time', 'required');
		$this->form_validation->set_rules('fees', 'Fees', 'required');
		$this->form_validation->set_rules('status', 'Status', 'required');

		if ($this->form_validation->run() == TRUE) {
			$package = array(
				'title' => trim($this->input->post('title')),
				'domain_date' => trim($this->input->post('domain_date')),
				'duration' => trim($this->input->post('duration')),
				'start_time' => trim($this->input->post('start_time')),
				'end_time' => trim($this->input->post('end_time')),
				'fees' => trim($this->input->post('fees')),
				'status' => $this->input->post('status'),
			);

			if (isset($_FILES['image']['name']) && $_FILES['image']['error'] == 0) {
				$temp_file = $_FILES['image']['tmp_name'];

				$img_name = "domain_" . mt_rand(10000, 999999999) . time();
				$path = $_FILES['image']['name'];

				$ext = pathinfo($path, PATHINFO_EXTENSION);

				$package['image'] = $img_name . "." . $ext;
				$url = DOMAINS . $package['image'];
				$this->gdb->compress_image($temp_file, $url, 80);
			}
			if (!empty($this->input->post('domain_id'))) {
				$id = $this->input->post('domain_id');
				$result = $this->domain_model->updateDomain($id, $package);
				if ($result) {
					$this->session->set_flashdata('success', "Domain Updated Successfully.");
				} else {
					$this->session->set_flashdata('error', "Error While Updateing Record.");
				}
			} else {
				$result = $this->domain_model->addDomain($package);
				if ($result) {
					$id = $result;
					$this->session->set_flashdata('success', "Domain Added Successfully.");
				} else {
					$this->session->set_flashdata('error', "Error While Inserting Record.");
				}
			}
			redirect(base_url('admin/domains'));
		}
		$this->load->view('admin/admin_master', $data);
	}

	public function delete() {
		$id = $this->input->post('id');
		$result = $this->domain_model->deleteDomain($id);
		if ($result) {
			echo json_encode(array('success' => 1, 'title' => 'Domain'));
			exit;
		}
		echo json_encode(array('success' => 0));
	}

}
