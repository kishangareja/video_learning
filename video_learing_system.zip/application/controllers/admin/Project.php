<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Project extends CI_Controller {

	function __construct() {

		parent::__construct();
		$this->load->model(array('project_model'));
		$this->load->model(array('tags_model'));
		$this->load->model(array('domain_model'));
		$this->gdb->checkAdminLogin();

	}

	public function index() {
		$data['project_data'] = $this->project_model->getProject();
		$data['view'] = 'admin/project/view';
		$data['page_title'] = 'Project List';
		$this->load->view('admin/admin_master', $data);
	}

	public function add($id = 0) {

		$id = $id + 0;
		$data['page_title'] = 'Add Project';
		$data['view'] = 'admin/project/add';
		$data['tags_data'] = $this->tags_model->getTags(1);
		$data['domain_data'] = $this->domain_model->getDomain(1);

		$action = 'Add';
		if ($id) {
			$this->data['page_title'] = 'Edit Project';
			$action = 'Edit';
		}

		if ($id) {
			$data['project_data'] = $this->project_model->getProjectById($id);
		}

		$this->form_validation->set_error_delimiters('<div id="alrt" class="alert alert-danger" style="padding:5px;margin-top:5px;">', '</div>');
		$this->form_validation->set_rules('domain_id', 'Domain', 'required');
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('description', 'Description', 'required');
		$this->form_validation->set_rules('video_link', 'Start Time', 'required');
		$this->form_validation->set_rules('software_link', 'End Time', 'required');
		$this->form_validation->set_rules('tags[]', 'Tags', 'required');
		$this->form_validation->set_rules('status', 'Status', 'required');

		if ($this->form_validation->run() == TRUE) {

			$project = array(
				'domain_id' => trim($this->input->post('domain_id')),
				'name' => trim($this->input->post('name')),
				'description' => trim($this->input->post('description')),
				'video_link' => trim($this->input->post('video_link')),
				'software_link' => trim($this->input->post('software_link')),
				'tags' => implode(",", $this->input->post('tags')),
				'status' => $this->input->post('status'),
			);

			if (isset($_FILES['block_diagram']['name']) && $_FILES['block_diagram']['error'] == 0) {
				$temp_file = $_FILES['block_diagram']['tmp_name'];

				$img_name = "block_diagram_" . mt_rand(10000, 999999999) . time();
				$path = $_FILES['block_diagram']['name'];

				$ext = pathinfo($path, PATHINFO_EXTENSION);

				$project['block_diagram'] = $img_name . "." . $ext;
				$url = PROJECT . $project['block_diagram'];
				$this->gdb->compress_image($temp_file, $url, 80);
			}

			if (isset($_FILES['related_document']['name']) && $_FILES['related_document']['error'] == 0) {
				$temp_file = $_FILES['related_document']['tmp_name'];

				$img_name = "related_document_" . mt_rand(10000, 999999999) . time();
				$path = $_FILES['related_document']['name'];

				$ext = pathinfo($path, PATHINFO_EXTENSION);

				$project['related_document'] = $img_name . "." . $ext;
				$url = PROJECT . $project['related_document'];
				$this->gdb->compress_image($temp_file, $url, 80);
			}

			if (isset($_FILES['image']['name'])) {
				$images_array = array();
				foreach ($_FILES['image']['name'] as $key => $image) {
					if ($_FILES['image']['error'][$key] == 0) {
						$temp_file = $_FILES['image']['tmp_name'][$key];
						$img_name = "image_" . mt_rand(10000, 999999999) . time();
						$path = $_FILES['image']['name'][$key];
						$ext = pathinfo($path, PATHINFO_EXTENSION);
						$project_image = $images_array[] = $img_name . "." . $ext;
						$url = PROJECT . $project_image;
						$this->gdb->compress_image($temp_file, $url, 80);

					}
				}
				$project['images'] = json_encode($images_array);
			}

			if (!empty($this->input->post('project_id'))) {
				$id = $this->input->post('project_id');
				$result = $this->project_model->updateProject($id, $project);
				if ($result) {
					$this->session->set_flashdata('success', "Project Updated Successfully.");
				} else {
					$this->session->set_flashdata('error', "Error While Updateing Record.");
				}
			} else {
				$result = $this->project_model->addProject($project);
				if ($result) {
					$id = $result;
					$this->session->set_flashdata('success', "Project Added Successfully.");
				} else {
					$this->session->set_flashdata('error', "Error While Inserting Record.");
				}
			}
			redirect(base_url('admin/project'));
		}
		$this->load->view('admin/admin_master', $data);
	}

	public function delete() {
		$id = $this->input->post('id');
		$result = $this->project_model->deleteProject($id);
		if ($result) {
			echo json_encode(array('success' => 1, 'title' => 'Project'));
			exit;
		}
		echo json_encode(array('success' => 0));
	}

}
