<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Domain_model extends CI_Model {

	/**
	 * Start Domain
	 */
	public function addDomain($data) {
		return $this->gdb->insert($this->common->getDomainTable(), $data);
	}

	public function getDomain($status = 0) {
		if ($status) {
			$this->gdb->where('status', $status);
		}
		return $this->gdb->get($this->common->getDomainTable())->result();
	}

	public function getDomainById($id) {
		$this->gdb->where('id', $id);
		return $this->gdb->get($this->common->getDomainTable())->row();
	}
	public function updateDomain($id, $data) {
		$this->gdb->where('id', $id);
		return $this->gdb->update($this->common->getDomainTable(), $data);
	}

	public function deleteDomain($id) {
		$this->gdb->where('id', $id);
		return $this->gdb->delete($this->common->getDomainTable());
	}

}
