<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Tags_model extends CI_Model {

	/**
	 * Start Tags
	 */
	public function addTags($data) {
		return $this->gdb->insert($this->common->getTagsTable(), $data);
	}

	public function getTags($status = 0) {
		if ($status) {
			$this->gdb->where('status', $status);
		}
		return $this->gdb->get($this->common->getTagsTable())->result();
	}

	public function getTagsById($id) {
		$this->gdb->where('id', $id);
		return $this->gdb->get($this->common->getTagsTable())->row();
	}
	public function updateTags($id, $data) {
		$this->gdb->where('id', $id);
		return $this->gdb->update($this->common->getTagsTable(), $data);
	}

	public function deleteTags($id) {
		$this->gdb->where('id', $id);
		return $this->gdb->delete($this->common->getTagsTable());
	}

	/**
	 * check existing
	 */
	public function checkExist($name) {
		$this->gdb->where('name', $name);
		return $this->gdb->get($this->common->getTagsTable())->row();
	}

}
