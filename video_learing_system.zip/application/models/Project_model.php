<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Project_model extends CI_Model {

	/**
	 * Start Project
	 */
	public function addProject($data) {
		return $this->gdb->insert($this->common->getProjectTable(), $data);
	}

	public function getProject($status = 0) {
		if ($status) {
			$this->gdb->where('status', $status);
		}
		return $this->gdb->get($this->common->getProjectTable())->result();
	}

	public function getProjectById($id) {
		$this->gdb->where('id', $id);
		return $this->gdb->get($this->common->getProjectTable())->row();
	}
	public function updateProject($id, $data) {
		$this->gdb->where('id', $id);
		return $this->gdb->update($this->common->getProjectTable(), $data);
	}

	public function deleteProject($id) {
		$this->gdb->where('id', $id);
		return $this->gdb->delete($this->common->getProjectTable());
	}

}
