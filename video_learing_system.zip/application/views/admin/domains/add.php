<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        <?php echo $page_title; ?>
        </h1>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-md-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"> <?php echo $page_title; ?></h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form"  method="post" action="<?php echo base_url('admin/domains/add/'); ?>" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group <?php echo ((form_error('title') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Title : </label>
                                <input type="text" name="title" class="form-control" id="exampleInputEmail1" placeholder="Enter Title" value="<?php echo isset($domain_data->title) ? $domain_data->title : set_value('title'); ?>">
                                <?php echo ((form_error('title') != "") ? '<span class="help-inline" style="color:red">' . form_error('title') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group <?php echo ((form_error('domain_date') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Date : </label>
                                <input type="text" name="domain_date" class="form-control" id="reservation" placeholder="Enter Date" value="<?php echo isset($domain_data->domain_date) ? $domain_data->domain_date : set_value('domain_date'); ?>">
                                <?php echo ((form_error('domain_date') != "") ? '<span class="help-inline" style="color:red">' . form_error('domain_date') . '</span>' : ''); ?>
                            </div>
                             <div class="form-group <?php echo ((form_error('duration') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Duration : </label>
                                <input type="text" name="duration" class="form-control" id="exampleInputEmail1" placeholder="Enter duration" value="<?php echo isset($domain_data->duration) ? $domain_data->duration : set_value('duration'); ?>">
                                <?php echo ((form_error('duration') != "") ? '<span class="help-inline" style="color:red">' . form_error('duration') . '</span>' : ''); ?>
                            </div>
                             <div class="form-group <?php echo ((form_error('start_time') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Start Time : </label>
                                <input type="text" name="start_time" class="form-control timepicker"  placeholder="Enter time" value="<?php echo isset($domain_data->start_time) ? $domain_data->start_time : set_value('start_time'); ?>">
                                <?php echo ((form_error('start_time') != "") ? '<span class="help-inline" style="color:red">' . form_error('start_time') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group <?php echo ((form_error('end_time') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">End Time : </label>
                                <input type="text" name="end_time" class="form-control timepicker"  placeholder="Enter time" value="<?php echo isset($domain_data->end_time) ? $domain_data->end_time : set_value('end_time'); ?>">
                                <?php echo ((form_error('end_time') != "") ? '<span class="help-inline" style="color:red">' . form_error('end_time') . '</span>' : ''); ?>
                            </div>

                            <div class="form-group <?php echo ((form_error('fees') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Fees : </label>
                                <input type="text" name="fees" class="form-control" id="exampleInputEmail1" placeholder="Enter fees" value="<?php echo isset($domain_data->fees) ? $domain_data->fees : set_value('fees'); ?>">
                                <?php echo ((form_error('fees') != "") ? '<span class="help-inline" style="color:red">' . form_error('fees') . '</span>' : ''); ?>
                            </div>

                            <div class="form-group <?php echo ((form_error('image') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Image : </label>
                                <input type="file" name="image" class="form-control" onchange="imagePreview(this)" id="exampleInputEmail1" placeholder="Enter name" value="<?php echo isset($domain_data->name) ? $domain_data->name : set_value('name'); ?>">
                                <img id="blah" src="<?php echo isset($domain_data->image) ? base_url() . DOMAINS . $domain_data->image : ''; ?>" alt="" height="60" width="60">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Status</label>
                                <select name="status" class="form-control" id="status">
                                    <option value="1" <?php if (isset($domain_data) && $domain_data->status == 1) {echo "selected";}?>>Active</option>
                                    <option value="0" <?php if (isset($domain_data) && $domain_data->status == 0) {echo "selected";}?>>In active</option>
                                </select>
                                <?php echo form_error('status'); ?>
                            </div>
                            <input type="hidden" name="domain_id" data-required="1"  class="form-control" value="<?php echo isset($domain_data->id) ? $domain_data->id : '' ?>" />
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="<?php echo base_url('admin/domains') ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                </div>
                <!-- /.box -->
            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script type="text/javascript">
function imagePreview(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();
reader.onload = function(e) {
$('#blah').attr('src', e.target.result);
}
reader.readAsDataURL(input.files[0]);
}
}
</script>