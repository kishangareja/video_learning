<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        <?php echo $page_title; ?>
        </h1>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-md-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"> <?php echo $page_title; ?></h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form"  method="post" action="<?php echo base_url('admin/project/add/'); ?>" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group <?php echo ((form_error('domain_id') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Domain : </label>
                                <select name="domain_id" class="form-control" data-placeholder="Select a State"
                                    style="width: 100%;">
                                    <option>--Select Domain--</option>
                                    <?php foreach ($domain_data as $value) {?>
                                    <option value="<?php echo $value->id ?>"><?php echo $value->title ?></option>
                                    <?php }?>
                                </select>
                                <?php echo ((form_error('domain_id') != "") ? '<span class="help-inline" style="color:red">' . form_error('domain_id') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group <?php echo ((form_error('name') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Project Name : </label>
                                <input type="text" name="name" class="form-control" id="exampleInputEmail1" placeholder="Enter name" value="<?php echo isset($project_data->name) ? $project_data->name : set_value('name'); ?>">
                                <?php echo ((form_error('name') != "") ? '<span class="help-inline" style="color:red">' . form_error('name') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group <?php echo ((form_error('block_diagram') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Block Diagram : </label>
                                <input type="file" name="block_diagram" class="form-control"  placeholder="Enter block diagrams" value="<?php echo isset($project_data->block_diagram) ? $project_data->block_diagram : set_value('block_diagram'); ?>">
                                <?php echo ((form_error('block_diagram') != "") ? '<span class="help-inline" style="color:red">' . form_error('block_diagram') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group <?php echo ((form_error('description') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Description : </label>
                                <textarea type="text" name="description" class="form-control"  placeholder="Enter description" ><?php echo isset($project_data->description) ? $project_data->description : set_value('description'); ?></textarea>
                                <?php echo ((form_error('description') != "") ? '<span class="help-inline" style="color:red">' . form_error('description') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group <?php echo ((form_error('video_link') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Video Link : </label>
                                <input type="text" name="video_link" class="form-control"  placeholder="Enter video link" value="<?php echo isset($project_data->video_link) ? $project_data->video_link : set_value('video_link'); ?>">
                                <?php echo ((form_error('video_link') != "") ? '<span class="help-inline" style="color:red">' . form_error('video_link') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group <?php echo ((form_error('componet_nodes') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Componet Nodes : </label>
                                <input type="text" name="componet_nodes" class="form-control"  placeholder="Enter component nodes" value="<?php echo isset($project_data->componet_nodes) ? $project_data->componet_nodes : set_value('componet_nodes'); ?>">
                                <?php echo ((form_error('componet_nodes') != "") ? '<span class="help-inline" style="color:red">' . form_error('componet_nodes') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group <?php echo ((form_error('software_link') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Software Link : </label>
                                <input type="text" name="software_link" class="form-control" id="exampleInputEmail1" placeholder="Enter software link" value="<?php echo isset($project_data->software_link) ? $project_data->software_link : set_value('software_link'); ?>">
                                <?php echo ((form_error('software_link') != "") ? '<span class="help-inline" style="color:red">' . form_error('software_link') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group <?php echo ((form_error('related_document') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Related Document : </label>
                                <input type="file" name="related_document" class="form-control" onchange="related_documentPreview(this)" id="exampleInputEmail1" placeholder="Enter name" value="<?php echo isset($project_data->name) ? $project_data->name : set_value('name'); ?>">
                            </div>
                            <div class="form-group <?php echo ((form_error('image') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Image : </label>
                                <input type="file" name="image[]" multiple="true" class="form-control" onchange="imagePreview(this)" id="exampleInputEmail1" placeholder="Enter name" value="<?php echo isset($project_data->name) ? $project_data->name : set_value('name'); ?>">
                                <img id="blah" src="<?php echo isset($project_data->image) ? base_url() . DOMAINS . $project_data->image : ''; ?>" alt="" height="60" width="60">
                            </div>
                            <div class="form-group <?php echo ((form_error('tags[]') != "") ? "has-error" : ""); ?>">
                                <label for="exampleInputEmail1">Tags : </label>
                                <select name="tags[]" class="form-control select2" multiple="multiple" data-placeholder="Select a State"
                                    style="width: 100%;">
                                    <option>--Select Tags--</option>
                                    <?php foreach ($tags_data as $value) {?>
                                    <option value="<?php echo $value->id ?>"><?php echo $value->name ?></option>
                                    <?php }?>
                                </select>
                                <?php echo ((form_error('tags[]') != "") ? '<span class="help-inline" style="color:red">' . form_error('tags[]') . '</span>' : ''); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Status</label>
                                <select name="status" class="form-control" id="status">
                                    <option value="1" <?php if (isset($project_data) && $project_data->status == 1) {echo "selected";}?>>Active</option>
                                    <option value="0" <?php if (isset($project_data) && $project_data->status == 0) {echo "selected";}?>>In active</option>
                                </select>
                                <?php echo form_error('status'); ?>
                            </div>
                            <input type="hidden" name="project_id" data-required="1"  class="form-control" value="<?php echo isset($project_data->id) ? $project_data->id : '' ?>" />
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                            <a href="<?php echo base_url('admin/project') ?>" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                </div>
                <!-- /.box -->
            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script type="text/javascript">
function imagePreview(input) {
if (input.files && input.files[0]) {
var reader = new FileReader();
reader.onload = function(e) {
$('#blah').attr('src', e.target.result);
}
reader.readAsDataURL(input.files[0]);
}
}
</script>